function loadTxt()
  {
    document.getElementById("txtName").innerHTML = "NAME:";
    document.getElementById("txtBookmark").innerHTML = "BOOKMARK:";
    document.getElementById("btnCancel").value = "CLOSE";
    document.getElementById("btnApply").value = "APPLY";
    document.getElementById("btnInsert").value = "INSERT";   
  }
function writeTitle()
  {
  document.write("<title>Bookmark</title>")
  }

