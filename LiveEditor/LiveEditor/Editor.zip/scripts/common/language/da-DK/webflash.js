﻿function loadTxt() {
    document.getElementById("lblSource").innerHTML = "Kilde:";
    document.getElementById("lblWidth").innerHTML = "BREDDE:";
    document.getElementById("lblHeight").innerHTML = "HØJDE:";
    document.getElementById("btnCancel").innerHTML = "annuller";
    document.getElementById("btnInsert").value = " indsæt ";
}

function writeTitle() {
    document.write("<title>Flash</title>")
}