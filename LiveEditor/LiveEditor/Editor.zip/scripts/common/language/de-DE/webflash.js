﻿function loadTxt() {
    document.getElementById("lblSource").innerHTML = "DATEI:";
    document.getElementById("lblWidth").innerHTML = "BREITE:";
    document.getElementById("lblHeight").innerHTML = "H&Ouml;HE:";
    document.getElementById("btnCancel").innerHTML = "abbrechen";
    document.getElementById("btnInsert").value = " einf\u00fcgen ";
}

function writeTitle() {
    document.write("<title>Flash</title>")
}