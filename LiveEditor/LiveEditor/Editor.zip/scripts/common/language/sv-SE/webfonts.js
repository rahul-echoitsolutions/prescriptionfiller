function loadTxt() {
    document.getElementById("tab0").innerHTML = "GOOGLE FONTER";
    document.getElementById("tab1").innerHTML = "BASFONTER";
    }
function writeTitle() {
    document.write("<title>" + "Fonter" + "</title>")
    }