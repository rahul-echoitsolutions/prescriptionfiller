InnovaStudio LIVE Editor 1.7.2
Copyright � 2012, INNOVA STUDIO (www.InnovaStudio.com). All rights reserved.
____________________________________________________________________


*** Quick Start ***
Open default.htm

*** Documentation ***
Open docs.htm (or docs_aspnet.htm for ASPNET users)

*** IMPORTANT NOTE ***

FILE BROWSER/MANAGER

FILE BROWSER/MANAGER IS A FREE ADD-ON INCLUDED IN INNOVASTUDIO LIVE EDITOR PACKAGE (in assetmanager folder).
SINCE IT IS A STANDALONE APPLICATION AND CAN BE ACCESSED DIRECTLY FROM BROWSER, 
YOU WILL NEED TO SECURE IT BY ADDING USER CHECK/AUTHENTICATION TO:

	- assetmanager/asset.[aspx/asp/php]

SECURITY CHECK MUST ALSO BE ADDED TO OTHER FILES IN FILE BROWSER FOLDER SUCH AS:

	- assetmanager/server/delfile.[ashx/asp/php]
	- assetmanager/server/delfolder.[ashx/asp/php]
	- assetmanager/server/newfolder.[ashx/asp/php]
	- assetmanager/server/upload.[ashx/asp/php]


*** Support ***
Email us at support@InnovaStudio.com (We provide 1 year free support). 


*** Credits ***

-------------------------------------------------------------------------------
jQuery JavaScript Library v1.7
http://jquery.com/
Copyright 2010, John Resig
Dual licensed under the MIT or GPL Version 2 licenses.
http://jquery.org/license

-------------------------------------------------------------------------------
CodeMirror
Copyright (C) 2011 by Marijn Haverbeke <marijnh@gmail.com>
MIT-style license.
http://codemirror.net/

-------------------------------------------------------------------------------
FancyBox - simple and fancy jQuery plugin
Examples and documentation at: http://fancy.klade.lv/
Copyright (c) 2009 Janis Skarnelis
Licensed under the MIT License: http://en.wikipedia.org/wiki/MIT_License

-------------------------------------------------------------------------------
Unobtrusive Slider Control / HTML5 Input Range polyfill - MIT/GPL2 @freqdec
http://www.frequency-decoder.com/2010/11/18/unobtrusive-slider-control-html5-input-range-polyfill

-------------------------------------------------------------------------------
jQuery miniColors: A small color selector
Dual licensed under the MIT or GPL Version 2 licenses
Copyright 2011 Cory LaViska for A Beautiful Site, LLC. (http://abeautifulsite.net/)
http://abeautifulsite.net/blog/2011/02/jquery-minicolors-a-color-selector-for-input-controls/

-------------------------------------------------------------------------------
reflection.js for jQuery v1.02
(c) 2006-2008 Christophe Beyls <http://www.digitalia.be>
MIT-style license.

-------------------------------------------------------------------------------
Spectrum: The No Hassle Colorpicker
https://github.com/bgrins/spectrum
Copyright (c) 2011, Brian Grinstead, http://briangrinstead.com
License: MIT

-------------------------------------------------------------------------------
jQTubeUtil - jQuery YouTube Search Utility
http://www.tikku.com/jquery-jqtube-util
Author: Nirvana Tikku (ntikku@gmail.com)
Dual licensed under the MIT and GPL licenses
http://www.opensource.org/licenses/mit-license.php
http://www.gnu.org/licenses/gpl.html

-------------------------------------------------------------------------------
Super Awesome Buttons with CSS3 and RGBA
http://www.zurb.com/article/266/super-awesome-buttons-with-css3-and-rgba

-------------------------------------------------------------------------------
jQuery File Tree Plugin
Version 1.01
Cory S.N. LaViska
http://www.abeautifulsite.net/blog/2008/03/jquery-file-tree/
This plugin is dual-licensed under the GNU General Public License and the MIT License and is copyright 2008 A Beautiful Site, LLC. 
--------------
A special thanks goes out to FAMFAMFAM for their excellent Silk Icon Set.
http://www.famfamfam.com/lab/icons/silk/

-------------------------------------------------------------------------------
Uploadify v2.1.4
Release Date: November 8, 2010
Copyright (c) 2010 Ronnie Garcia, Travis Nickels
http://www.uploadify.com/

-------------------------------------------------------------------------------
Sample script: Uploadify and Classic ASP 
http://www.uploadify.quickersite.com/r/

-------------------------------------------------------------------------------
Free ASP Upload
http://www.freeaspupload.net/

-------------------------------------------------------------------------------
Subtle Patterns
Collection of high quality design patterns
http://subtlepatterns.com/
This work is licensed under a Creative Commons Attribution 3.0 Unported License.

-------------------------------------------------------------------------------
jquery.event.drag - v 2.0.0 
Copyright (c) 2010 Three Dub Media - http://threedubmedia.com
Open Source MIT License - http://threedubmedia.com/code/license
http://threedubmedia.com/code/event/drag

-------------------------------------------------------------------------------
Tutorials

http://playground.mobily.pl/tutorials/how-to-create-youtube-search-engine.html (How to create your own Youtube search engine)
http://webexpedition18.com/download/css3_text_shadow/
http://www.amazingthings.in/2011/07/css3-text-shadow-tutorial-simple_03.html
http://blog.echoenduring.com/2010/05/13/create-beautiful-css3-typography/
http://sixrevisions.com/css/how-to-create-inset-typography-with-css3/
http://www.webdesigndev.com/web-development/16-gorgeous-web-safe-fonts-to-use-with-css

http://www.ampsoft.net/webdesign-l/WindowsMacFonts.html
http://www.nogginbox.co.uk/blog/canvas-and-multi-touch
http://haacked.com/archive/2009/12/29/convert-rgb-to-hex.aspx
http://www.javascripter.net/faq/hextorgb.htm
http://stackoverflow.com/questions/1134976/how-may-i-sort-a-list-alphabetically-using-jquery

-------------------------------------------------------------------------------
This product uses the Flickr API but is not endorsed or certified by Flickr (www.flickr.com).



____________________________________________________________________
http://www.InnovaStudio.com
