<?php

define("WEBSITEROOT_LOCALPATH", $_SERVER['DOCUMENT_ROOT']);
define("UPLOAD_FILE_TYPES", "jpg|jpeg|gif|png|txt|pdf|zip");
?>